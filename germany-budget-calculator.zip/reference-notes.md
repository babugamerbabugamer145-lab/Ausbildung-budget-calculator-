# Reference Notes: Germany Monthly Budget Calculator PDF

## Visual direction
- Dark premium dashboard style with charcoal background, gold primary accents, and red warning accents.
- Large display headlines, strong contrast, framed cards, subtle glows, and financial dashboard motifs.
- Germany cues appear through skyline silhouettes, Germany map texture, and euro symbolism.

## Core budgeting model
- **Free cash = Income (Netto) - Committed costs - Flexible spending - Savings.**
- The user should quickly understand whether the current monthly plan is affordable.

## Budget categories observed in the PDF
### Income
- Gross salary
- Deductions (taxes and social security)
- Netto / take-home salary
- Recurring additional income
- Bonus
- Child benefit
- Freelance income
- Support

### Housing / committed costs
- Warm rent (Warmmiete)
- Utilities and home services
- Total housing stack
- Housing affordability guardrail around 35% of net income, warning above 40%

### Everyday spending / flexible costs
- Groceries
- Household supplies
- Eating out
- Personal and clothing
- Leisure
- Transport
- Insurance and health
- Phone

### Future and irregular costs
- Annual costs converted into monthly sinking funds
- Travel
- Gifts
- Retirement / long-term reserve
- Emergency fund / savings

## Reporting ideas implied by the PDF
- Show headline affordability result and remaining monthly free cash.
- Show housing ratio against net income and visually flag safe/caution/high ranges.
- Show category-level spending breakdown with a donut or similar chart.
- Include total monthly spending, monthly savings, and leftover cash in a summary report.
- Make the result understandable for people moving to Germany, comparing cities, or planning as a couple.

## Implementation direction for the website
- Include editable inputs for salary, rent, groceries, transport, utilities, insurance, phone, eating out, household, personal, leisure, savings, emergency fund, travel, gifts, and other costs.
- Provide instant totals, affordability insights, and a printable/shareable on-page report section.
- Preserve the premium Germany-focused financial aesthetic while making the calculator practical and mobile-friendly.
