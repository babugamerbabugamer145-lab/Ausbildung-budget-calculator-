/* Rhine Ledger design reminder: an asymmetric editorial finance workspace. Keep brass reserved for opportunity and actions, red for pressure, and make the free-cash verdict visible before the details. */

import { useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowUpRight,
  BarChart3,
  Building2,
  CalendarDays,
  CheckCircle2,
  CircleDollarSign,
  Coffee,
  Gift,
  Home as HomeIcon,
  Info,
  PiggyBank,
  Plane,
  Printer,
  Receipt,
  ShieldCheck,
  ShoppingBasket,
  Smartphone,
  Sparkles,
  Train,
  Utensils,
  Wallet,
} from "lucide-react";

type BudgetValues = {
  grossSalary: number;
  deductions: number;
  additionalIncome: number;
  rent: number;
  utilities: number;
  groceries: number;
  household: number;
  eatingOut: number;
  personal: number;
  leisure: number;
  transport: number;
  insurance: number;
  phone: number;
  travel: number;
  gifts: number;
  other: number;
  savings: number;
  emergency: number;
};

type NumericField = keyof BudgetValues;
type ExpenseTone = "brass" | "red" | "steel";

const initialBudget: BudgetValues = {
  grossSalary: 4200,
  deductions: 1200,
  additionalIncome: 250,
  rent: 1150,
  utilities: 180,
  groceries: 350,
  household: 80,
  eatingOut: 160,
  personal: 120,
  leisure: 120,
  transport: 69,
  insurance: 130,
  phone: 35,
  travel: 100,
  gifts: 50,
  other: 75,
  savings: 250,
  emergency: 150,
};

const presets: Record<string, BudgetValues> = {
  "Single professional": initialBudget,
  Couple: {
    grossSalary: 6200,
    deductions: 1900,
    additionalIncome: 400,
    rent: 1600,
    utilities: 250,
    groceries: 600,
    household: 130,
    eatingOut: 220,
    personal: 200,
    leisure: 180,
    transport: 138,
    insurance: 240,
    phone: 60,
    travel: 180,
    gifts: 80,
    other: 120,
    savings: 600,
    emergency: 250,
  },
  "Young family": {
    grossSalary: 7000,
    deductions: 2200,
    additionalIncome: 500,
    rent: 1900,
    utilities: 300,
    groceries: 850,
    household: 190,
    eatingOut: 140,
    personal: 240,
    leisure: 160,
    transport: 160,
    insurance: 280,
    phone: 75,
    travel: 150,
    gifts: 80,
    other: 160,
    savings: 500,
    emergency: 300,
  },
};

const money = new Intl.NumberFormat("de-DE", {
  style: "currency",
  currency: "EUR",
  maximumFractionDigits: 0,
});

const compactMoney = new Intl.NumberFormat("de-DE", {
  style: "currency",
  currency: "EUR",
  maximumFractionDigits: 0,
  notation: "compact",
});

const formatEuro = (value: number) => money.format(Math.round(value));
const formatCompactEuro = (value: number) => compactMoney.format(Math.round(value));
const clamp = (value: number, min: number, max: number) => Math.min(Math.max(value, min), max);

const expenseSections = [
  {
    id: "committed",
    eyebrow: "01 / COMMITTED COSTS",
    title: "Keep the lights on",
    description: "Costs that arrive before the month gets started.",
    tone: "brass" as ExpenseTone,
    fields: [
      { key: "rent" as NumericField, label: "Warm rent", hint: "Rent incl. service charges", icon: HomeIcon },
      { key: "utilities" as NumericField, label: "Utilities", hint: "Energy, internet, home services", icon: Building2 },
      { key: "transport" as NumericField, label: "Transport", hint: "Deutschlandticket, fuel, mobility", icon: Train },
      { key: "insurance" as NumericField, label: "Insurance & health", hint: "Monthly premiums and co-pays", icon: ShieldCheck },
      { key: "phone" as NumericField, label: "Phone & data", hint: "Mobile and subscriptions", icon: Smartphone },
    ],
  },
  {
    id: "flexible",
    eyebrow: "02 / FLEXIBLE SPENDING",
    title: "Live the month",
    description: "Everyday choices you can steer without losing the plot.",
    tone: "steel" as ExpenseTone,
    fields: [
      { key: "groceries" as NumericField, label: "Groceries", hint: "Food and beverages", icon: ShoppingBasket },
      { key: "household" as NumericField, label: "Household", hint: "Supplies and small repairs", icon: Receipt },
      { key: "eatingOut" as NumericField, label: "Eating out", hint: "Restaurants, cafés, takeaways", icon: Utensils },
      { key: "personal" as NumericField, label: "Personal & clothing", hint: "Care, clothes, essentials", icon: Sparkles },
      { key: "leisure" as NumericField, label: "Leisure", hint: "Culture, hobbies, going out", icon: Coffee },
      { key: "other" as NumericField, label: "Other monthly costs", hint: "Anything not listed above", icon: CircleDollarSign },
    ],
  },
  {
    id: "future",
    eyebrow: "03 / FUTURE COSTS",
    title: "Make room for later",
    description: "Turn annual surprises into calm monthly line items.",
    tone: "red" as ExpenseTone,
    fields: [
      { key: "travel" as NumericField, label: "Travel fund", hint: "Trips and visits home", icon: Plane },
      { key: "gifts" as NumericField, label: "Gifts & occasions", hint: "Birthdays, holidays, celebrations", icon: Gift },
      { key: "savings" as NumericField, label: "Long-term savings", hint: "Goals, investing, retirement", icon: PiggyBank },
      { key: "emergency" as NumericField, label: "Emergency fund", hint: "Buffer for the unexpected", icon: ShieldCheck },
    ],
  },
];

function NumberInput({
  value,
  onChange,
  label,
  hint,
  icon: Icon,
  accent = "brass",
}: {
  value: number;
  onChange: (value: string) => void;
  label: string;
  hint: string;
  icon: typeof Wallet;
  accent?: ExpenseTone;
}) {
  return (
    <label className={`number-field number-field-${accent}`}>
      <span className="number-field-icon" aria-hidden="true"><Icon size={17} strokeWidth={1.7} /></span>
      <span className="number-field-copy">
        <span className="number-field-label">{label}</span>
        <span className="number-field-hint">{hint}</span>
      </span>
      <span className="number-field-value">
        <span className="currency-prefix">€</span>
        <input
          type="number"
          min="0"
          step="10"
          inputMode="decimal"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          aria-label={`${label} per month`}
        />
      </span>
    </label>
  );
}

function SectionRule({ tone = "brass" }: { tone?: ExpenseTone }) {
  return <span className={`section-rule section-rule-${tone}`} aria-hidden="true"><i /><i /><i /></span>;
}

export default function Home() {
  const [budget, setBudget] = useState<BudgetValues>(initialBudget);
  const [activePreset, setActivePreset] = useState("Single professional");
  const [toast, setToast] = useState("");
  const reportRef = useRef<HTMLDivElement>(null);

  const updateField = (field: NumericField, rawValue: string) => {
    const parsed = Number(rawValue);
    setBudget((current) => ({ ...current, [field]: Number.isFinite(parsed) && parsed >= 0 ? parsed : 0 }));
    setActivePreset("");
  };

  const calculations = useMemo(() => {
    const netSalary = Math.max(budget.grossSalary - budget.deductions, 0);
    const netIncome = netSalary + budget.additionalIncome;
    const housing = budget.rent + budget.utilities;
    const committed = housing + budget.transport + budget.insurance + budget.phone;
    const everyday = budget.groceries + budget.household + budget.eatingOut + budget.personal + budget.leisure + budget.other;
    const future = budget.travel + budget.gifts;
    const savings = budget.savings + budget.emergency;
    const plannedOutgo = committed + everyday + future + savings;
    const freeCash = netIncome - plannedOutgo;
    const housingRatio = netIncome ? (housing / netIncome) * 100 : 0;
    const savingsRate = netIncome ? (savings / netIncome) * 100 : 0;
    const spendTotal = committed + everyday + future + savings;
    const categories = [
      { label: "Housing", value: housing, color: "#D7A64A", icon: HomeIcon },
      { label: "Everyday", value: everyday, color: "#A9B5C5", icon: ShoppingBasket },
      { label: "Future costs", value: future, color: "#C63B3B", icon: CalendarDays },
      { label: "Savings", value: savings, color: "#E7C77D", icon: PiggyBank },
    ];
    const status = freeCash < 0 ? "Over budget" : housingRatio > 40 ? "Housing heavy" : housingRatio > 35 ? "Tight but workable" : "On track";
    const statusTone = freeCash < 0 || housingRatio > 40 ? "danger" : housingRatio > 35 ? "caution" : "good";
    return { netSalary, netIncome, housing, committed, everyday, future, savings, plannedOutgo, freeCash, housingRatio, savingsRate, spendTotal, categories, status, statusTone };
  }, [budget]);

  const donutGradient = useMemo(() => {
    const total = calculations.spendTotal || 1;
    let cursor = 0;
    const stops = calculations.categories.map((category) => {
      const start = (cursor / total) * 100;
      cursor += category.value;
      const end = (cursor / total) * 100;
      return `${category.color} ${start}% ${end}%`;
    });
    return `conic-gradient(${stops.join(", ")})`;
  }, [calculations.categories, calculations.spendTotal]);

  const applyPreset = (name: string) => {
    setBudget(presets[name]);
    setActivePreset(name);
    setToast(`${name} plan loaded`);
    window.setTimeout(() => setToast(""), 2200);
  };

  const buildReport = () => {
    reportRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    setToast("Report updated from your latest numbers");
    window.setTimeout(() => setToast(""), 2400);
  };

  const copySummary = async () => {
    const summary = `Rhine Ledger monthly plan\nNet income: ${formatEuro(calculations.netIncome)}\nPlanned outgo: ${formatEuro(calculations.plannedOutgo)}\nFree cash: ${formatEuro(calculations.freeCash)}\nHousing ratio: ${Math.round(calculations.housingRatio)}%\nSavings rate: ${Math.round(calculations.savingsRate)}%`;
    try {
      await navigator.clipboard.writeText(summary);
      setToast("Summary copied to clipboard");
    } catch {
      setToast("Copy is unavailable in this browser");
    }
    window.setTimeout(() => setToast(""), 2200);
  };

  return (
    <div className="app-shell">
      {toast && <div className="toast" role="status">{toast}</div>}
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Rhine Ledger home">
          <img src="/manus-storage/rhine-ledger-mark_83321aea.png" alt="" className="brand-mark" />
          <span className="brand-name"><strong>RHINE</strong><span>LEDGER</span></span>
        </a>
        <div className="topbar-meta"><span className="flag-mark"><i /><i /><i /></span><span>GERMANY / MONTHLY PLANNER</span></div>
        <nav className="topnav" aria-label="Primary navigation">
          <a href="#planner">Planner</a>
          <a href="#report">Report</a>
          <button type="button" className="top-print" onClick={() => window.print()}><Printer size={15} /> Print</button>
        </nav>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-image" aria-hidden="true" />
          <div className="hero-content page-width">
            <div className="hero-copy">
              <p className="eyebrow"><span className="eyebrow-line" /> 2026 / PERSONAL FINANCE SYSTEM</p>
              <h1>Know what<br /><em>your month</em><br />can carry.</h1>
              <p className="hero-description">A clear Germany-first view of take-home pay, committed costs, everyday spending, and the cash you can actually keep.</p>
              <div className="hero-actions">
                <a className="button button-brass" href="#planner">Plan your month <ArrowUpRight size={16} /></a>
                <a className="text-link" href="#report">See how the report works <span>↘</span></a>
              </div>
            </div>
            <div className="hero-verdict">
              <div className="hero-verdict-top"><span>LIVE MONTHLY VERDICT</span><span className="live-dot" /> </div>
              <div className="hero-verdict-number">{formatEuro(calculations.freeCash)}</div>
              <div className="hero-verdict-label">free cash after your plan</div>
              <div className="hero-verdict-divider" />
              <div className="hero-verdict-stats">
                <div><span>NET INCOME</span><strong>{formatEuro(calculations.netIncome)}</strong></div>
                <div><span>PLANNED OUTGO</span><strong>{formatEuro(calculations.plannedOutgo)}</strong></div>
              </div>
              <div className={`verdict-chip ${calculations.statusTone}`}>
                {calculations.statusTone === "good" ? <CheckCircle2 size={14} /> : <AlertTriangle size={14} />}
                {calculations.status}
              </div>
            </div>
          </div>
          <div className="hero-foot page-width"><span>Built for life in Germany</span><span>Taxes + rent + real life, in one view</span><span>EUR / month</span></div>
        </section>

        <section className="planner-section page-width" id="planner">
          <aside className="planner-sidebar">
            <p className="eyebrow"><span className="eyebrow-line" /> YOUR MONTHLY PLAN</p>
            <h2>Start with<br /><em>what arrives.</em></h2>
            <p className="sidebar-copy">Use real numbers, not rough guesses. The report updates as you shape the month.</p>
            <div className="profile-panel">
              <div className="profile-title"><span>QUICK PROFILE</span><Info size={15} /></div>
              <p>Choose a starting point, then make it yours.</p>
              <div className="profile-buttons">
                {Object.keys(presets).map((name) => <button key={name} className={activePreset === name ? "active" : ""} type="button" onClick={() => applyPreset(name)}>{name}</button>)}
              </div>
            </div>
            <div className="sidebar-note"><span className="note-icon"><BarChart3 size={17} /></span><span><strong>Good to know</strong><br />Housing is usually the decision that shapes everything else.</span></div>
          </aside>

          <div className="planner-canvas">
            <div className="income-card">
              <div className="card-heading-row">
                <div><p className="eyebrow small">INCOME / WHAT ACTUALLY ARRIVES</p><h3>Your monthly payslip</h3></div>
                <span className="icon-badge brass"><Wallet size={18} /></span>
              </div>
              <div className="income-grid">
                <NumberInput value={budget.grossSalary} onChange={(value) => updateField("grossSalary", value)} label="Gross salary" hint="Before tax and contributions" icon={Wallet} />
                <NumberInput value={budget.deductions} onChange={(value) => updateField("deductions", value)} label="Taxes & social security" hint="Estimated monthly deductions" icon={Receipt} accent="red" />
                <NumberInput value={budget.additionalIncome} onChange={(value) => updateField("additionalIncome", value)} label="Other recurring income" hint="Benefits, support, side income" icon={CircleDollarSign} accent="steel" />
              </div>
              <div className="net-income-band"><div><span>NETTO / TAKE-HOME PAY</span><strong>{formatEuro(calculations.netSalary)}</strong></div><div className="net-income-plus">+ {formatEuro(budget.additionalIncome)} <span>recurring income</span></div><div className="net-income-total"><span>PLANNED INCOME</span><strong>{formatEuro(calculations.netIncome)}</strong></div></div>
            </div>

            {expenseSections.map((section) => (
              <section className="expense-section" key={section.id}>
                <div className="expense-heading"><div><p className={`eyebrow small tone-${section.tone}`}>{section.eyebrow}</p><h3>{section.title}</h3><p>{section.description}</p></div><SectionRule tone={section.tone} /></div>
                <div className="field-grid">
                  {section.fields.map((field) => <NumberInput key={field.key} value={budget[field.key]} onChange={(value) => updateField(field.key, value)} label={field.label} hint={field.hint} icon={field.icon} accent={section.tone} />)}
                </div>
                <div className={`section-total section-total-${section.tone}`}><span>SECTION TOTAL</span><strong>{formatEuro(section.id === "committed" ? calculations.committed : section.id === "flexible" ? calculations.everyday : calculations.future + calculations.savings)}</strong><span>/ month</span></div>
              </section>
            ))}

            <div className="planner-cta">
              <div><p className="eyebrow small">READY FOR THE ANSWER?</p><h3>Turn your inputs into a useful monthly report.</h3></div>
              <button type="button" className="button button-brass" onClick={buildReport}>Build my monthly report <ArrowUpRight size={16} /></button>
            </div>
          </div>
        </section>

        <section className="report-section" id="report" ref={reportRef}>
          <div className="report-backdrop" aria-hidden="true" />
          <div className="page-width report-inner">
            <div className="report-heading-row"><div><p className="eyebrow"><span className="eyebrow-line" /> MONTHLY REPORT / AUGUST 2026</p><h2>Your month, <em>decoded.</em></h2><p className="report-intro">A practical read on what your current plan can carry—before the next payday arrives.</p></div><div className="report-actions"><button className="button button-outline" type="button" onClick={copySummary}>Copy summary</button><button className="button button-brass" type="button" onClick={() => window.print()}><Printer size={16} /> Print report</button></div></div>
            <div className="report-grid">
              <div className="report-main-card">
                <div className="report-status-row"><span className={`status-icon ${calculations.statusTone}`}>{calculations.statusTone === "good" ? <CheckCircle2 size={20} /> : <AlertTriangle size={20} />}</span><div><span className="report-label">YOUR MONTHLY ANSWER</span><h3>{calculations.freeCash >= 0 ? "You have room to breathe." : "Your plan needs a reset."}</h3><p>{calculations.freeCash >= 0 ? `After planned costs and savings, ${formatEuro(calculations.freeCash)} remains unassigned.` : `Your plan is ${formatEuro(Math.abs(calculations.freeCash))} above available income. Start with flexible spending.`}</p></div></div>
                <div className="report-big-number"><span>FREE CASH</span><strong className={calculations.freeCash < 0 ? "negative" : ""}>{formatEuro(calculations.freeCash)}</strong><small>/ month</small></div>
                <div className="report-metric-grid"><div><span>NET INCOME</span><strong>{formatEuro(calculations.netIncome)}</strong><small>100% of available</small></div><div><span>PLANNED OUTGO</span><strong>{formatEuro(calculations.plannedOutgo)}</strong><small>{calculations.netIncome ? Math.round((calculations.plannedOutgo / calculations.netIncome) * 100) : 0}% allocated</small></div><div><span>SAVINGS RATE</span><strong>{Math.round(calculations.savingsRate)}%</strong><small>{formatEuro(calculations.savings)} set aside</small></div></div>
              </div>
              <div className="breakdown-card"><div className="card-heading-row"><div><span className="report-label">WHERE THE MONTH GOES</span><h3>Spending plan</h3></div><span className="icon-badge steel"><BarChart3 size={18} /></span></div><div className="donut-wrap"><div className="donut" style={{ background: donutGradient }}><div className="donut-hole"><strong>{formatCompactEuro(calculations.spendTotal)}</strong><span>planned</span></div></div><div className="donut-legend">{calculations.categories.map((category) => { const Icon = category.icon; return <div className="legend-row" key={category.label}><span className="legend-dot" style={{ background: category.color }} /><Icon size={14} /><span>{category.label}</span><strong>{formatEuro(category.value)}</strong></div>; })}</div></div></div>
            </div>

            <div className="guardrail-grid">
              <div className={`guardrail-card ${calculations.housingRatio > 40 ? "danger" : calculations.housingRatio > 35 ? "caution" : ""}`}><div className="guardrail-top"><span className="guardrail-icon"><HomeIcon size={18} /></span><span className="report-label">HOUSING GUARDRAIL</span><strong>{Math.round(calculations.housingRatio)}%</strong></div><div className="meter"><span style={{ width: `${clamp(calculations.housingRatio, 0, 100)}%` }} /></div><div className="guardrail-copy"><span>Target ≤ 35%</span><span>Warning at 40%</span></div><p>{calculations.housingRatio <= 35 ? "Your housing stack leaves healthy room for everyday life." : calculations.housingRatio <= 40 ? "Housing is getting tight. Keep flexible costs visible." : "Housing is carrying too much of the plan. Review rent or add income before stretching further."}</p></div>
              <div className="guardrail-card savings-card"><div className="guardrail-top"><span className="guardrail-icon"><PiggyBank size={18} /></span><span className="report-label">FUTURE YOU</span><strong>{formatEuro(calculations.savings)}</strong></div><div className="future-bars"><span style={{ height: `${clamp((budget.savings / Math.max(calculations.savings, 1)) * 100, 10, 100)}%` }} /><span style={{ height: `${clamp((budget.emergency / Math.max(calculations.savings, 1)) * 100, 10, 100)}%` }} /><span style={{ height: "70%" }} /><span style={{ height: "86%" }} /><span style={{ height: "100%" }} /></div><p>Each month, you’re assigning {formatEuro(calculations.savings)} to long-term goals and your buffer.</p></div>
              <div className="annual-card"><span className="report-label">IF YOU KEEP THIS PACE</span><strong>{formatEuro(calculations.freeCash * 12)}</strong><span>unassigned free cash in 12 months</span><div className="annual-line"><span /><ArrowUpRight size={17} /></div><p>Use the leftover deliberately: top up the emergency fund, travel, or a bigger German-life goal.</p></div>
            </div>

            <div className="report-table-card"><div className="report-table-heading"><div><span className="report-label">MONTHLY STATEMENT</span><h3>Every euro has a place.</h3></div><span>EUR / MONTH</span></div><div className="statement-rows"><div className="statement-row income-row"><span><i className="statement-dot brass" /> Available income</span><strong>{formatEuro(calculations.netIncome)}</strong></div><div className="statement-row"><span><i className="statement-dot brass" /> Committed costs</span><strong>- {formatEuro(calculations.committed)}</strong></div><div className="statement-row"><span><i className="statement-dot steel" /> Everyday spending</span><strong>- {formatEuro(calculations.everyday)}</strong></div><div className="statement-row"><span><i className="statement-dot red" /> Future costs</span><strong>- {formatEuro(calculations.future)}</strong></div><div className="statement-row"><span><i className="statement-dot gold" /> Savings & emergency fund</span><strong>- {formatEuro(calculations.savings)}</strong></div><div className="statement-row total-row"><span>Free cash / what’s left for you</span><strong className={calculations.freeCash < 0 ? "negative" : ""}>{formatEuro(calculations.freeCash)}</strong></div></div></div>

            <div className="report-footer-row"><div><span className="report-label">THE SHORT VERSION</span><p>{calculations.status === "On track" ? "Your plan is balanced: housing is inside the guardrail, savings are present, and there is room left after the essentials." : calculations.status === "Tight but workable" ? "Your plan works, but housing is close to the upper guardrail. Keep flexible spending honest and revisit the rent number if circumstances change." : calculations.status === "Housing heavy" ? "Your biggest lever is housing. Before adding new commitments, test a lower rent, a shared setup, or a stronger income line." : "The plan is currently upside down. Begin with flexible costs, then revisit fixed commitments before optimizing savings."}</p></div><div className="source-note"><Info size={14} /><span>Planning guidance based on the category structure in the supplied reference. This is a personal planning tool, not tax advice.</span></div></div>
          </div>
        </section>
      </main>

      <footer className="site-footer"><div className="page-width footer-inner"><div className="footer-brand"><img src="/manus-storage/rhine-ledger-mark_83321aea.png" alt="" /><span><strong>RHINE</strong> LEDGER</span></div><p>Make the month legible.</p><span className="footer-date">GERMANY / EUR / 2026</span></div><img className="footer-skyline" src="/manus-storage/rhine-ledger-skyline_ea0259a3.png" alt="" /></footer>
    </div>
  );
}
