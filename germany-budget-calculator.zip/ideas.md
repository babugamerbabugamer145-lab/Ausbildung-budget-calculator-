# Design Direction — Germany Monthly Budget Calculator

## Three possible directions

### Theme Name: Rhine Ledger
**Very Brief Intro:** A dark editorial finance dashboard with warm brass highlights, red alert signals, and a quiet German city-at-night atmosphere. It makes monthly money decisions feel grounded, premium, and consequential.

**Probability:** 0.03

### Theme Name: Bauhaus Balance
**Very Brief Intro:** A light, architectural budgeting workspace built from cream paper, ink-black type, cobalt marks, and red geometry. It treats the monthly plan like a clear, practical German design object.

**Probability:** 0.07

### Theme Name: Moss & Marble
**Very Brief Intro:** A calm, natural planning tool in stone, forest green, and muted amber, with soft shapes and a more domestic feel. It positions budgeting as sustainable household care rather than financial pressure.

**Probability:** 0.01

## Selected direction: Rhine Ledger

### Design Movement
Contemporary editorial finance design with cues from German modernism, night transit signage, and premium annual-report art direction.

### Core Principles
1. **Make the decision visible:** The remaining free cash and affordability state should read before the user studies the details.
2. **Contrast is functional:** Warm brass is reserved for opportunity and primary actions; signal red is reserved for pressure, warnings, and thresholds.
3. **Structure before decoration:** Every panel should support one budgeting decision, with strong labels, aligned numbers, and clear category grouping.
4. **Quiet confidence:** Use depth, fine rules, and restrained motion rather than noisy gradients, excessive rounding, or novelty effects.

### Color Philosophy
The base is a near-black blue-charcoal that echoes the PDF’s night skyline and gives high contrast to financial figures. Brass-gold signals money that is available or well-managed. A restrained German red marks overspend, caution, and boundary conditions without turning the experience into an alarm. Paper-tinted text and muted steel preserve legibility while keeping the surface premium.

### Layout Paradigm
Use an asymmetric command-center layout: a narrow vertical rail for context and navigation, a wide working canvas for editable inputs, and a fixed-feeling insight column that keeps the monthly verdict in view. Sections should feel stacked like a financial statement, not arranged as a centered marketing grid.

### Signature Elements
- A compact “free cash” verdict block with a brass outline and a tiny German flag signal.
- Fine-line skyline/map textures used sparingly as atmosphere behind hero and report areas.
- Category rows with icon chips, inline progress bars, and left-edge signal markers.

### Interaction Philosophy
Editing should feel like tuning an instrument: direct, immediate, and reversible. Numeric changes update totals without modal friction. Focus states use brass outlines; warnings appear as contextual guidance beside the affected category. Buttons should state what they do, such as “Update report” or “Print report,” rather than generic filler.

### Animation
Use 160–220ms ease-out transitions for hover, focus, and expanding detail. Let summary numbers softly count or slide into place only when values change materially. Stagger the first render by 40ms between major panels. Avoid looping motion; allow only a subtle signal pulse on warning states, and respect reduced-motion preferences.

### Typography System
Use **Space Grotesk** for display figures and headings: compact, technical, and slightly human. Use **DM Sans** for body copy, labels, and controls: highly readable at small sizes. Hierarchy: uppercase 11px eyebrow labels with tracking, 18–28px section titles, 48–72px key monetary verdicts, and 13–15px body copy with generous line-height.

### Brand Essence
A monthly money command center for people living in, moving to, or planning life in Germany—different because it turns scattered costs into one clear decision.

**Personality:** grounded, exacting, reassuring.

### Brand Voice
Headlines are direct and composed. CTAs are action-oriented and specific. Microcopy is plain-English with occasional German terms in context, never jargon-heavy or patronizing.

Example headline: **“Know what your month can carry.”**

Example CTA: **“Build my monthly report.”**

### Wordmark & Logo
A compact monogram mark built from three horizontal ledger bars that align into a stylized “G” while leaving a small negative-space euro stroke in the center. The wordmark uses a custom all-caps condensed treatment with a brass square stop, not a default text logo.

### Signature Brand Color
**Ledger Brass — #D7A64A.** It owns the space between bank gold and muted paper, feeling valuable without becoming flashy.
